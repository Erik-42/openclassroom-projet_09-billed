export default [
    'cedric.hiely@billed.com',
    'christian.saluzzo@billed.com',
    'jean.limbert@billed.com',
    'joanna.binet@billed.com'
]