const app = require('./app');

app.listen(5678, () => {
  // eslint-disable-next-line no-console
  console.log('Example app listening on port 5678!');
});
